doobwa Trading Cards
v1.02 (January 30th, 2021)
Created by doobwa with special thanks to abspade.

========== INTRODUCTION ==========

Hi, thanks for installing the doobwa Trading Cards resource pack!

This card pack alters the vanilla game in *NO WAY*, it is purely an add-on pack.

To utilize this resource pack, you must have the latest installation of:
	> Optifine: https://optifine.net
	> Java: https://www.java.com

The pack uses Optifine's custom item feature, to ensure the custom item ability is enabled open up your Minecraft options and navigate to VIDEO SETTINGS > QUALITY > CUSTOM ITEMS. Once there make sure the option is "ON".

========== INSTALLATION ========== 

Once you've downloaded the pack, you should recieve it as a .zip file. You can open the zip file and should see a folder called "doobwa Trading Cards". This folder is different from the zip folder, you can tell because the zip folder has the current version on it and the folder inside does not. Copy the folder WITHOUT the version on it, called "doobwa Trading Cards".

Open Minecraft, press "Options" and then press the "Resource Packs" tab. Press the "Open Pack Folder" and paste the doobwa Trading Cards folder inside.

The resource pack should appear in the "Available" section of your resource packs, you can then press the resource pack to apply it to your "Selected" packs. From there you are good to go!

ALL FUTURE INSTALLATIONS CAN BE FOUND IN MY DISCORD: https://discord.gg/Zqn3bQ3J8U

========== HOW TO FIND THE CUSTOM ITEMS ==========

When in game, you can find the custom trading cards by taking a piece of paper and renaming it in an anvil. Each card has a specific name you must give it to acquire the texture. To access these official names, do the following:
	1. Open your Minecraft options, naviagate to RESOURCE PACKS and open your resource pack folder.
	2. From there, open up your doobwa Trading Cards folder.
	3. Once in the pack, you should immidiately see the PLAYERLIST document, open that file to access the official texture names.
	4. Find the series and username you want, then copy the ENTIRE line of text for that card.
		> It should be formatted as such: "doobwa trading card (##) playername".
	
Once you have located the specific name for the card you want, you can rename the piece of paper with that name, and your paper's texture *should* change.

========== MISC. ==========

To ask questions or request additions/changes, you can message me on discord. The easiest way to find me is through Discord. My username is doobwa#0001 and I most frequent this server: https://discord.gg/bnK6yzCHPv.
	You can find me on the server and send me a message.

For context, this pack was born in 2021 inside of another resource pack called StaplerItems by abspade. It was created for an SMP server called the Dullstaples SMP. The server was ran by Stapler, who goes by the alias @dullstaples (@dullerstaples, too) on Instagram. I helped both admin the SMP and work on the resource pack. I added doobwa Trading Cards as a gimmick to the server, but also because I love trading cards myself. The SMP would eventually close in November of 2021. In January of 2022, I created this pack to continue using my trading cards.

========== COMING SOON/TO-DO LIST ==========

> Add new players.

========== CHANGELOG ==========

January 14th 2021 (v1.00): Initial release.
January 16th 2021 (v1.01): Ease of access upgrade and general housekeeping.
	> Fixed bug with square characters showing up next to food items.
	> Revamped acquisition process for cards, now available through anvil instead of commands.
	> Added playerlist.txt and fixed naming issue with certain cards.
	> Updated splash text list.
	> Updated resource pack logo.
	> Minor changes to update naming system, fix cosmetic issues and general bug fixes.
January 30th 2021 (v1.02): Doobcraft update.
	> Added pack installation guide in README file.
	> Minor cosmetic changes.
	> Added the Doobcraft series (Series 11, 12 players).